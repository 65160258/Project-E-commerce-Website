import express from "express";
import ejs from "ejs";
import bodyParser from "body-parser";
import mysql from "mysql";
import session from "express-session";

import authRoutes from "./routes/authRoutes.js";
import productRoutes from "./routes/productRoutes.js";
import cartRoutes from "./routes/cartRoutes.js";
import paymentRoutes from "./routes/paymentRoutes.js";


const app = express();
app.listen(8080, () => {
    console.log("Server is running on http://localhost:8080");
});

app.use(express.static("public"));
app.set("view engine", "ejs");
app.use(bodyParser.urlencoded({ extended: true }));
app.use(session({ secret: "secret", resave: false, saveUninitialized: false }));


// Create MySQL connection pool
const con = mysql.createPool({
    connectionLimit: 10,
    host: "localhost",
    user: "root",
    password: "",
    database: "e-commerce",
});

// Home route to display products
app.get("/", function (req, res) {
    const searchQuery = req.query.search || ''; // Get search query from request

    // SQL query to filter products
    const sql = searchQuery
        ? "SELECT * FROM products WHERE name LIKE ?"
        : "SELECT * FROM products";

    const values = searchQuery ? [`%${searchQuery}%`] : [];

    con.query(sql, values, (err, result) => {
        if (err) {
            console.log(err);
            res.send("There was an error loading the products.");
        } else {
            res.render("pages/index.ejs", { result: result, session: req.session, searchQuery: searchQuery }); // Pass searchQuery here
        }
    });
});


// Use the route modules
app.use("/", authRoutes);
app.use("/", productRoutes);
app.use("/", cartRoutes);
app.use("/", paymentRoutes);

app.get('/new-arrival', (req, res) => {
    res.render('new-arrival');
});

app.get('/features', (req, res) => {
    res.render('features');
});

app.get('/blog', (req, res) => {
    res.render('blog');
});

app.get('/contact', (req, res) => {
    res.render('contact');
});
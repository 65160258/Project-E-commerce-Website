import express from "express";
import bcrypt from "bcrypt";
import mysql from "mysql";

const router = express.Router();
const con = mysql.createPool({
    connectionLimit: 10,
    host: "localhost",
    user: "root",
    password: "",
    database: "e-commerce",
});

// Signup route
router.get("/signup", (req, res) => {
    res.render("pages/signup.ejs");
});

router.post("/signup", (req, res) => {
    const { username, email, password } = req.body;
    const hashedPassword = bcrypt.hashSync(password, 10);

    const query = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
    con.query(query, [username, email, hashedPassword], (err) => {
        if (err) {
            console.error(err);
            return res.status(500).send("Error signing up");
        }
        res.redirect("/login");
    });
});

// Login route
router.get("/login", (req, res) => {
    res.render("pages/login.ejs");
});

router.post("/login", function (req, res) {
    const { username, password } = req.body;
    const query = "SELECT * FROM users WHERE username = ?";
    con.query(query, [username], (err, results) => {
        if (err) {
            console.error(err);
            return res.send("Error during login.");
        }

        if (results.length > 0) {
            const user = results[0];
            bcrypt.compare(password, user.password, (err, match) => {
                if (err) {
                    console.error(err);
                    return res.send("Error during login.");
                }

                if (match) {
                    req.session.userId = user.id;
                    req.session.username = user.username;
                    req.session.role = user.role;

                    if (user.role === 'staff') {
                        res.redirect("/manage-products");
                    } else {
                        res.redirect("/");
                    }
                } else {
                    res.send("Invalid credentials.");
                }
            });
        } else {
            res.send("User not found.");
        }
    });
});

// Logout route
router.get("/logout", (req, res) => {
    req.session.destroy(err => {
        if (err) {
            console.error(err);
            return res.status(500).send("Error logging out");
        }
        res.redirect("/");
    });
});

export default router;

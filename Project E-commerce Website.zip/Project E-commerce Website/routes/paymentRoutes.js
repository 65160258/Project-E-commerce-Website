import express from "express";
import mysql from "mysql";

const router = express.Router();
const con = mysql.createPool({
    connectionLimit: 10,
    host: "localhost",
    user: "root",
    password: "",
    database: "e-commerce",
});

// Route to view order history
router.get("/order_history", function (req, res) {
    if (!req.session.userId) {
        return res.redirect("/login");
    }

    const username = req.session.username; // Get the username from the session

    const query = "SELECT * FROM payments WHERE username = ?";
    
    con.query(query, [username], (err, results) => {
        if (err) {
            console.error(err);
            return res.send("There was an issue retrieving your order history.");
        }
        res.render("pages/order_history.ejs", { orders: results });
    });
});

// Payment route
router.get("/payment", (req, res) => {
    const total = req.session.total || 0;
    res.render("pages/payment.ejs", { total: total });
});

// Process payment
router.post("/process_payment", (req, res) => {
    const { payment_method, amount } = req.body;
    const order_id = req.session.order_id; // Get order_id from the session
    const username = req.session.username; // Get username from the session

    const payment_status = "completed"; // Payment status
    const payment_date = new Date();

    const paymentQuery = "INSERT INTO payments (order_id, payment_method, payment_status, amount, payment_date, username) VALUES ?";
    const paymentValues = [[order_id, payment_method, payment_status, amount, payment_date, username]];

    con.query(paymentQuery, [paymentValues], (err) => {
        if (err) {
            console.log(err);
            return res.send("There was an issue processing your payment. Please try again.");
        }

        // Update the order status to "Paid"
        const updateOrderQuery = "UPDATE orders SET status = ? WHERE id = ?";
        con.query(updateOrderQuery, ["Paid", order_id], (err) => {
            if (err) {
                console.log(err);
                return res.send("There was an issue updating your order status. Please try again.");
            }

            // Clear the cart and total after payment is successful
            req.session.cart = [];
            req.session.total = 0;
            res.send(
                `<h1>Payment successful! Thank you for your order.</h1>
                <br><br>Click <a href="/">here</a> to continue shopping.`
            );
        });
    });
});

export default router;
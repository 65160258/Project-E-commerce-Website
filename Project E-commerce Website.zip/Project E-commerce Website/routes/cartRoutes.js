import express from "express";
import mysql from "mysql";

const router = express.Router();
const con = mysql.createPool({
    connectionLimit: 10,
    host: "localhost",
    user: "root",
    password: "",
    database: "e-commerce",
});

// Add to cart
router.post("/add_to_cart", (req, res) => {
    if (!req.session.userId) {
        return res.redirect("/login");
    }

    const { id, name, price, sale_price, quantity, image } = req.body;
    const product = { id, name, price, sale_price, quantity, image };

    // Initialize cart if it doesn't exist
    let cart = req.session.cart || [];

    // Check if the product is already in the cart
    if (!isProductInCart(cart, id)) {
        cart.push(product);
    }

    req.session.cart = cart;
    calculateTotal(cart, req);
    res.redirect("/cart");
});

// View cart
router.get("/cart", (req, res) => {
    const cart = req.session.cart || [];
    const total = calculateTotal(cart, req);
    res.render("pages/cart.ejs", { cart: cart, total: total });
});

// Remove product from cart
router.post("/remove_product", (req, res) => {
    const id = req.body.id;
    let cart = req.session.cart || [];

    // Filter out the product from the cart
    cart = cart.filter(product => product.id !== id);
    req.session.cart = cart; // Update session cart

    calculateTotal(cart, req);
    res.redirect("/cart");
});

// Edit product quantity
router.post("/edit_product_quantity", (req, res) => {
    const { id, quantity, increase_product_quantity, decrease_product_quantity } = req.body;
    const cart = req.session.cart || [];

    for (let product of cart) {
        if (product.id === id) {
            if (increase_product_quantity) {
                product.quantity = parseInt(product.quantity) + 1;
            }
            if (decrease_product_quantity && product.quantity > 1) {
                product.quantity = parseInt(product.quantity) - 1;
            }
            break; // Break after finding the product
        }
    }
    req.session.cart = cart; // Update session cart
    calculateTotal(cart, req);
    res.redirect("/cart");
});

// Checkout route
router.post("/checkout", (req, res) => {
    const total = req.session.total || 0;
    res.render("pages/checkout.ejs", { total: total });
});

// Place order
router.post("/place_order", (req, res) => {
    const { name, email, phone, city, address } = req.body;
    const cost = req.session.total || 0; // Ensure cost is defined
    const status = "not paid";
    const date = new Date();
    const username = req.session.username;

    const query = "INSERT INTO orders (name, email, phone, city, address, cost, status, date, username) VALUES ?";
    const values = [[name, email, phone, city, address, cost, status, date, username]];

    con.query(query, [values], (err, result) => {
        if (err) {
            console.log(err);
            return res.send("There was an issue processing your order. Please try again.");
        }
        req.session.order_id = result.insertId; // Store order ID in session
        res.redirect("/payment");
    });
});

// Helper functions
function isProductInCart(cart, productId) {
    return cart.some(product => product.id == productId);
}

function calculateTotal(cart, req) {
    const total = cart.reduce((sum, item) => sum + item.sale_price * item.quantity, 0);
    req.session.total = total;
    return total;
}

export default router;

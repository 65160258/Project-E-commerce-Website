import express from "express";
import mysql from "mysql";

const router = express.Router();
const con = mysql.createPool({
    connectionLimit: 10,
    host: "localhost",
    user: "root",
    password: "",
    database: "e-commerce",
});

// Route to display the product management page
router.get("/manage-products", function (req, res) {
    // Check if the user is logged in and has the 'staff' role
    if (!req.session.userId || req.session.role !== 'staff') {
        return res.redirect("/login");
    }

    // Query to get products from the database
    con.query("SELECT * FROM products", (err, products) => {
        if (err) {
            console.log(err);
            return res.send("There was an error loading products.");
        }
        
        // Render the manage-products page and pass the products and session data
        res.render("pages/manage-products.ejs", { 
            products: products, 
            session: req.session // Pass session data
        });
    });
});


// Route to add a new product
router.post("/add_product", function(req, res) {
    const { name, price, sale_price, image, image_details, description } = req.body;

    const query = "INSERT INTO products (name, price, sale_price, image, image_details, description) VALUES (?, ?, ?, ?, ?, ?)";
    con.query(query, [name, price, sale_price, image, image_details, description], (err, result) => {
        if (err) {
            console.log(err);
            return res.send("There was an error adding the product.");
        }
        res.redirect("/manage-products");
    });
});


// Route to delete a product
router.post("/delete_product", (req, res) => {
    const { id } = req.body;
    const query = "DELETE FROM products WHERE id = ?";
    con.query(query, [id], (err) => {
        if (err) {
            console.log(err);
            return res.send("Error deleting product.");
        }
        res.redirect("/manage-products");
    });
});

// Route to update a product
router.post('/edit_product', function(req, res) {
    const { id, name, price, sale_price, image, description } = req.body;

    const query = "UPDATE products SET name = ?, price = ?, sale_price = ?, image = ?, description = ? WHERE id = ?";
    con.query(query, [name, price, sale_price, image, description, id], (err, result) => {
        if (err) {
            console.log(err);
            return res.send("There was an error updating the product.");
        }
        res.redirect('/manage-products'); // Redirect back to manage products after updating
    });
});


router.get("/products/:id", function (req, res) {
    const productId = req.params.id;

    con.query("SELECT * FROM products WHERE id = ?", [productId], (err, product) => {
        if (err) {
            console.log(err);
            return res.send("There was an error loading the product details.");
        }
        if (product.length === 0) {
            return res.status(404).send("Product not found.");
        }
        
        // Render the product details page and pass the product data
        res.render("pages/product-details.ejs", { product: product[0], session: req.session });
    });
});


export default router;
